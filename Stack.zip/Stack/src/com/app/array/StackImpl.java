package com.app.array;

import java.util.Arrays;

public class StackImpl<T> implements Stack<T> {

	private int top;
	private Object[] stackArray;
	private int size;

	public StackImpl(int n) {
		super();
		this.top = -1;
		this.stackArray = new Object[n];
		this.size = n;
	}

	@Override
	public T push(T element) {
		if (isFull()) {
			resizeStack();
		}
		++top;
		stackArray[top] = element;
		return element;
	}

	@Override
	public T pop() throws StackException {
		if (isEmpty()) {
			throw new StackException("Stack underflow !!");

		}
		return (T) stackArray[top--];
	}

	@Override
	public T peek() throws StackException {
		if (isEmpty()) {
			throw new StackException("Stack underflow !!");
		}
		return (T) stackArray[top];
	}

	@Override
	public boolean isFull() {
//		if (top == size-1)
//			return true;
//		return false;
		return top == size - 1;
	}

	@Override
	public boolean isEmpty() {
//	    if(top==-1)
//	    	return true;
//		return false;
		return top == -1;
	}

	public void resizeStack() {
		size = size * 2;
		stackArray = Arrays.copyOf(stackArray, size);

	}

	public void display() {
		int temp = top;
		while (temp != -1) {
			System.out.print(stackArray[temp] + " ");
			temp--;
		}
	}

	public Object[] getStackArray() {
		return stackArray;
	}

	public void setStackArray(Object[] stackArray) {
		this.stackArray = stackArray;
	}
	
}
