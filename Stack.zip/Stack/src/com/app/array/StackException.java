package com.app.array;

public class StackException extends Exception {

	public StackException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
