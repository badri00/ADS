package com.app.array;

import java.util.Arrays;

public class Tester {

	public static void main(String[] args) {
		try {
			StackImpl stack = new StackImpl(5);
			for (int i = 1; i <= 5; i++)
				System.out.println("Element " + stack.push(i) + " is pushed into the stack");
               
			stack.display();
			System.out.println();
			System.out.println(Arrays.toString(stack.getStackArray()));
			System.out.println();
			System.out.println("Is stack full:" + stack.isFull());

			System.out.println("Element " + stack.pop() + " is removed from stack");

			stack.display();
			System.out.println();
			
			System.out.println("Top most element in stack is:" + stack.peek());

			System.out.println("Is stack empty:" + stack.isEmpty());

			System.out.println("Is stack full:" + stack.isFull());

			System.out.println("Name " + stack.push("Vivek") + " is pushed into the stack");

			
			System.out.println(Arrays.toString(stack.getStackArray()));
			stack.display();
			System.out.println();
			
			for (int i = 1; i <= 10; i++) {
				stack.pop();
			}

		} catch (Exception e) {
			System.out.println(e);
		}

	}

}
