package com.app.linkedList;

public class Tester {

	public static void main(String[] args) {
		try {
			StackImpl stack = new StackImpl();
			for (int i = 1; i <= 10; i++)
				System.out.println("Element " + stack.push(i) + " is pushed into the stack");

			System.out.println("Element " + stack.pop() + " is removed from stack");

			System.out.println("Top most element in stack is:" + stack.peek());

			System.out.println("Is stack empty:" + stack.isEmpty());

			System.out.println("Name " + stack.push("Vivek") + " is pushed into the stack");

			for (int i = 1; i <= 10; i++) {
				stack.pop();
			}
			System.out.println("Is stack empty:" + stack.isEmpty());

			System.out.println("Element " + stack.pop() + " is removed from stack");

		} catch (Exception e) {
			System.out.println(e);
		}

	}

}
