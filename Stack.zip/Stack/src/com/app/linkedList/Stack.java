package com.app.linkedList;

public interface Stack<T> {

	T push(T element);

	T pop() throws StackException;

	T peek() throws StackException;

	boolean isEmpty();

}
