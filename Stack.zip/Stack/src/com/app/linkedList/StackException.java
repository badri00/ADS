package com.app.linkedList;

public class StackException extends RuntimeException {

	public StackException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
