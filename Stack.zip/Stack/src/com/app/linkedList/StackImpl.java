package com.app.linkedList;

public class StackImpl<T> implements Stack<T> {

	class Node {
		T data;
		Node next;

		public Node() {
			super();
			this.data = null;
			this.next = null;
		}

		public Node(T data) {
			super();
			this.data = data;
			this.next = null;
		}

	}

	private Node top;

	public StackImpl() {
		super();
		this.top = null;
	}

	@Override
	public T push(T element) {

		Node newNode = new Node(element);
		if (isEmpty())
			top = newNode;
		else {
			newNode.next = top;
			top = newNode;
		}

		return element;
	}

	@Override
	public T pop() /*throws StackException*/ {
		if (isEmpty()) {
			throw new StackException("Stack underflow !!");

		} else {
			T popped = top.data;
			top = top.next;
			return popped;
		}
	}

	@Override
	public T peek() {
		if (isEmpty()) {
			throw new StackException("Stack underflow !!");
		} else {
			return top.data;
		}
	}

	@Override
	public boolean isEmpty() {

		return top == null;
	}

}
