package com.app.circularQueueUsingArray;

import java.util.Arrays;

public class QueueTester {

	public static void main(String[] args) {
         try {
		QueueImpl<Integer>queue = new QueueImpl<Integer>(4);
		queue.enqueue(1);
		System.out.println(Arrays.toString(queue.getQueue()));
		System.out.println("is queue full:" + queue.isFull());
		queue.enqueue(2);
		System.out.println(Arrays.toString(queue.getQueue()));
		System.out.println("is queue full:" + queue.isFull());
		queue.enqueue(3);
		System.out.println(Arrays.toString(queue.getQueue()));
		System.out.println("is queue full:" + queue.isFull());

		System.out.println("removed Element is:"+queue.dequeue());
		queue.enqueue(4);
		System.out.println(Arrays.toString(queue.getQueue()));
		System.out.println("is queue full:" + queue.isFull());
		System.out.println("removed Element is:"+queue.dequeue());
		System.out.println("removed Element is:"+queue.dequeue());
		System.out.println("is queue empty:" + queue.isEmpty());
		System.out.println("removed Element is:"+queue.dequeue());
         }catch(Exception e) {
        	 System.out.println(e);
         }
	}

}
