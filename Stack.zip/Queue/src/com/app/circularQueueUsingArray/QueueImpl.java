package com.app.circularQueueUsingArray;

public class QueueImpl<T> implements Queue<T> {

	private int front;
	private int rear;
	private T[] queue;

	public QueueImpl(int size) {
		front = 0;
		rear = 0;
		queue = (T[]) new Object[size];
	}

	@Override
	public void enqueue(T element) {
		if (isFull())
			throw new QueueException("queue is full");
		rear = (rear + 1) % queue.length;
		queue[rear] = element;

	}

	@Override
	public T dequeue() {

		if (isEmpty())
			throw new QueueException("queue is empty");
		front = (front + 1) % queue.length;
		T x = queue[front];
		queue[front] = null;
		return x;
	}

	public T[] getQueue() {
		return queue;
	}

	@Override
	public boolean isEmpty() {

//		if (rear == front)
//			return true;
//		return false;
		return rear == front;
	}

	@Override
	public boolean isFull() {

//		if ((rear+1)%queue.length==front)
//			return true;
//		return false;
		return (rear + 1) % queue.length == front;
	}

}
