package com.app.linearQueueUsingArray;

public class QueueImpl<T> implements Queue<T> {

	private int front;
	private int rear;
	private T[] queue;

	public QueueImpl(int size) {
		front = -1;
		rear = -1;
		queue = (T[]) new Object[size];
	}

	@Override
	public void enqueue(T element) {
		if (isFull())
			throw new QueueException("queue is full");
		rear++;
		queue[rear] = element;

	}

	@Override
	public T dequeue() {

		if (isEmpty())
			throw new QueueException("queue is empty");
		front++;
        T x=queue[front];
        queue[front]=null;
		return x;
	}

	public int getFront() {
		return front;
	}

	public int getRear() {
		return rear;
	}

	public T[] getQueue() {
		return queue;
	}

	@Override
	public boolean isEmpty() {

//		if (rear == front)
//			return true;
//		return false;
		return rear==front;
	}

	@Override
	public boolean isFull() {

//		if (rear == queue.length - 1)
//			return true;
//		return false;
		return rear == queue.length - 1;
	}

}
