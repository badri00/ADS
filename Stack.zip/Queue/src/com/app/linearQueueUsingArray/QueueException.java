package com.app.linearQueueUsingArray;

public class QueueException extends RuntimeException {

	public QueueException(String mesg)
	{
		super(mesg);
	}
}
