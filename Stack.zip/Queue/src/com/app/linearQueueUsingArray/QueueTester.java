package com.app.linearQueueUsingArray;

import java.util.Arrays;

public class QueueTester {

	public static void main(String[] args) {
         try {
		QueueImpl<Integer>queue = new QueueImpl<Integer>(3);
		queue.enqueue(1);
		System.out.println(Arrays.toString(queue.getQueue()));
		queue.enqueue(2);
		System.out.println(Arrays.toString(queue.getQueue()));
		queue.enqueue(3);
		System.out.println(Arrays.toString(queue.getQueue()));
		System.out.println("is queue full:" + queue.isFull());
		// queue.enqueue(4);
		System.out.println(queue.dequeue());
		System.out.println(queue.dequeue());
		System.out.println(queue.dequeue());
		System.out.println("is queue empty:" + queue.isEmpty());
		System.out.println(queue.dequeue());
         }catch(Exception e) {
        	 System.out.println(e);
         }
	}

}
