package com.app.circularQueueUsingLinkedList;

public interface Queue<T> {

	void enqueue(T element);
	T dequeue();
	boolean isEmpty();
	void display();
}
