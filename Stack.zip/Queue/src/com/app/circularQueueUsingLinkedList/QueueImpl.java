package com.app.circularQueueUsingLinkedList;

public class QueueImpl<T> implements Queue<T> {
	class Node {

		T data;
		Node next;

		public Node() {
			super();
			this.data = null;
			this.next = null;
		}

		public Node(T data) {
			super();
			this.data = data;
			this.next = null;
		}

	}

	private Node front;
	private Node rear;

	public QueueImpl() {
		front = null;
		rear = null;
	}

	@Override
	public void enqueue(T element) {
		Node newNode = new Node(element);
		if (isEmpty())
			front = newNode;
		else {
			rear.next = newNode;
		}
		rear = newNode;
		rear.next = front;

	}

	@Override
	public T dequeue() {

		if (isEmpty())
			throw new QueueException("queue is empty");

		Node temp = front;
		if (front == rear) {
			front = null;
			rear = null;
		} else {
			front = front.next;
			rear.next = front;
		}

		return temp.data;
	}

	@Override
	public boolean isEmpty() {

//		if ( front==null && rear==null)
//			return true;
//		return false;
		return front == null && rear == null;
	}

	@Override
	public void display() {
		if (isEmpty()) {
			System.out.println("Queue is empty");
			return;
		}
		Node current = front;
		do {
			System.out.print(current.data + " ");
			current = current.next;
		} while (current != front);

	}

}
