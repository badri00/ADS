package com.app.circularQueueUsingLinkedList;

import java.util.Arrays;

public class QueueTester {

	public static void main(String[] args) {
		try {
			QueueImpl queue = new QueueImpl();
			queue.enqueue(1);
			queue.enqueue(2);
			queue.enqueue(3);
			queue.display();
			System.out.println();
			System.out.println("removed Element is:" + queue.dequeue());
			queue.enqueue(4);
			queue.display();
			System.out.println();

			System.out.println("removed Element is:" + queue.dequeue());
			System.out.println("removed Element is:" + queue.dequeue());
			System.out.println("is queue empty:" + queue.isEmpty());
			System.out.println("removed Element is:" + queue.dequeue());
			System.out.println("is queue empty:" + queue.isEmpty());
			System.out.println("removed Element is:" + queue.dequeue());
			System.out.println("is queue empty:" + queue.isEmpty());
		} catch (Exception e) {
			System.out.println(e);
		}
	}

}
