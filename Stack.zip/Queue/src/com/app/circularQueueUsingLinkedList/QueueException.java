package com.app.circularQueueUsingLinkedList;

public class QueueException extends RuntimeException {

	public QueueException(String mesg)
	{
		super(mesg);
	}
}
