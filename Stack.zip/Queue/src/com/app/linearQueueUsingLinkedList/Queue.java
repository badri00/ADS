package com.app.linearQueueUsingLinkedList;

public interface Queue<T> {

	void enqueue(T element);
	T dequeue();
	boolean isEmpty();
	void display();
	
}
