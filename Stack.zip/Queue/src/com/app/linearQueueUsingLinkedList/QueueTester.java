package com.app.linearQueueUsingLinkedList;

import java.util.Arrays;

public class QueueTester {

	public static void main(String[] args) {
		try {
			QueueImpl queue = new QueueImpl();

			queue.enqueue(1);
			queue.enqueue(2);
			queue.enqueue(3);
			queue.enqueue(4);
			queue.enqueue("Vivek");
			queue.display();
			System.out.println();

			System.out.println("removed Element is:" +queue.dequeue());
			System.out.println("removed Element is:" +queue.dequeue());
			System.out.println("removed Element is:" +queue.dequeue());
			System.out.println("removed Element is:" +queue.dequeue());
			System.out.println("removed Element is:" +queue.dequeue());
			System.out.println("is queue empty:" + queue.isEmpty());
		} catch (Exception e) {
			System.out.println(e);
		}
	}

}
