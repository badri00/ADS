package com.app.linearQueueUsingLinkedList;

public class QueueException extends RuntimeException {

	public QueueException(String mesg)
	{
		super(mesg);
	}
}
