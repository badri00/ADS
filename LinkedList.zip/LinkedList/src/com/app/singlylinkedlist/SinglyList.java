package com.app.singlylinkedlist;

public interface SinglyList <T>{

    T addNewElement(T element,int position);
	void addFirst(T element);
	void addLast(T element);
	void deleteFirst();
	void deleteLast();
	void deleteElement(int position);
	void deleteAll();
	void reverseList();
	void moveNodeToFirstPosition(T element);
	void insertInSortedList(T element) throws SinglyListExceptions;
	void removeDuplicateElements();
}
