package com.app.singlylinkedlist;

import com.app.doublylinkedlist.DoublyLinkedListImpl.Node;

public class SinglyListImpl<T> implements SinglyList<T> {

	class Node {
		private T data;
		private Node next;

		public Node() {
			super();
			this.data = null;
			this.next = null;
		}

		public Node(T data) {
			super();
			this.data = data;
			this.next = null;
		}

	}

	Node head;
	Node tail;
	Node current;
	Node temp;

	public SinglyListImpl() {
		super();
		this.head = null;
		this.tail = null;
	}

	@Override
	public T addNewElement(T element, int position) {

		if (head == null || position <= 1)
			addFirst(element);
		else {
			Node newNode = new Node(element);
			current = head;
			for (int i = 1; i < position - 1; i++) {
				if (current.next == null)
					throw new SinglyListExceptions("Position is greater than number of nodes");
				current = current.next;
			}
			newNode.next = current.next;
			current.next = newNode;

		}
		return element;
	}

	@Override
	public void addFirst(T element) {
		Node newNode = new Node(element);
		if (head == null) {

			tail = newNode;

		}
		newNode.next = head;
		head = newNode;

	}

	@Override
	public void addLast(T element) {

		Node newNode = new Node(element);
		current = head;
		if (head == null) {
			head = tail = newNode;
		} else {
			while (current.next != null) {
				current = current.next;
			}
			current.next = newNode;
		}
	}

	void displayList() {

		current = head;
		while (current != null) {
			System.out.println(current.data);
			current = current.next;
		}

	}

	@Override
	public void deleteFirst() {
		if (head == null)
			throw new SinglyListExceptions("List is empty");

		head = head.next;

	}

	@Override
	public void deleteLast() {
		if (head == null)
			throw new SinglyListExceptions("List is empty");
		if (head.next == null)
			head = null;
		else {
			temp = null;
			current = head;
			while (current.next != null) {
				temp = current;
				current = current.next;
			}
			temp.next = null;

		}
	}

	@Override
	public void deleteElement(int position) {
		current = head;
		temp = null;
		if (position == 1)
			deleteFirst();
		else {
			for (int i = 1; current != null && i < position; i++) {
				temp = current;
				current = current.next;
			}

			temp.next = current.next;

		}
	}

	@Override
	public void deleteAll() {
		head = null;
	}

	public void reverseList() {

		current = head;
		temp = null;
		Node temp2 = null;

		while (current != null) {
			temp2 = temp;
			temp = current;
			current = current.next;
			temp.next = temp2;
		}
		head = temp;

	}

	public void moveNodeToFirstPosition(T element) {

		current = head;
		temp = null;
		if (head.data == element) {
		} else {
			while (!(current.data == element)) {
				temp = current;
				current = current.next;
			}
			temp.next = current.next;
			current.next = head;
			head = current;

		}
	}

	public void insertInSortedList(T element) throws SinglyListExceptions {
		Node newNode = new Node(element);
		current = head;
		temp = null;
		if (current.data != newNode.data) {
			if ((int) head.data > (int) newNode.data) {
				newNode.next = head;
				head = newNode;
			} else {
				while (current != null && (int) current.data < (int) newNode.data) {
					temp = current;
					current = current.next;
				}
				temp.next = newNode;
				newNode.next = current;
			}
		} else
			throw new SinglyListExceptions("element already exists!!");
	}

	public void removeDuplicateElements() {
		current = head.next;
		temp = head;
		while (current != null) {
			if (current.data != temp.data) {
				temp = current;
				current = current.next;
			} else {
				temp.next = current.next;
				current = temp.next;
			}

		}

	}

	public SinglyListImpl<T> mergeList(SinglyListImpl<T> list, SinglyListImpl<T> secondList) {
		SinglyListImpl<T> list2 = new SinglyListImpl<>();
		Node first = list.head;
		Node second = secondList.head;
		Node last = null;

		if (first == null) {
			list2.head = second;
			return list2;
		}
		if (second == null) {
			list2.head = first;
			return list2;
		}
		if ((int) first.data < (int) second.data) {
			list2.head = last = first;
			first = first.next;

		} else {
			list2.head = last = second;
			second = second.next;
		}
		while (first != null && second != null) {
			if ((int) first.data < (int) second.data) {
				last.next = first;
				last = first;
				first = first.next;
			} else {

				last.next = second;
				last = second;
				second = second.next;
			}
		}
		if (first != null)
			last.next = first;
		else
			last.next = second;

		return list2;
	}
}
