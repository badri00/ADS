package com.app.doublylinkedlist;

public class DoublyLinkedListExceptions extends RuntimeException {

	public DoublyLinkedListExceptions(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
