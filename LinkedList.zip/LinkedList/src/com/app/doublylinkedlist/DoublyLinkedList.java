package com.app.doublylinkedlist;

public interface DoublyLinkedList<T> {
	T addNewElement(T element, int position);

	void addFirst(T element);

	void addLast(T element);

	void deleteFirst();

	void deleteLast();

	void deleteFromGivenPosition(int position);

	void display();

	boolean search(T element);
}
