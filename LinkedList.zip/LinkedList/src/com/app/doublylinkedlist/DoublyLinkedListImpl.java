package com.app.doublylinkedlist;

import com.app.singlylinkedlist.SinglyListExceptions;

public class DoublyLinkedListImpl<T> implements DoublyLinkedList<T> {

	public class Node {

		T data;
		Node pre;
		Node next;

		public Node(T data) {
			super();
			this.data = data;
			this.pre = null;
			this.next = null;
		}

		public Node() {
			super();
			this.data = null;
			this.pre = null;
			this.next = null;
		}
	}

	Node head;
	Node tail;
	Node current;
	Node temp;

	public DoublyLinkedListImpl() {
		super();
		this.head = null;
		this.tail = null;
	}

	@Override
	public T addNewElement(T element, int position) {

		if (head == null || position <= 1)
			addFirst(element);
		else {
			Node newNode = new Node(element);
			current = head;
			for (int i = 1; i < position - 1; i++) {
				if (current.next == null)
					throw new DoublyLinkedListExceptions("Position is greater than number of nodes");
				current = current.next;
			}

			newNode.next = current.next;
			current.next = newNode;
			newNode.pre = current;
			current.next.pre = newNode;
		}

		return element;
	}

	@Override
	public void addFirst(T element) {
		Node newNode = new Node(element);
		if (head == null) {
			head = tail = newNode;
		} else {
			newNode.next = head;
			head.pre = newNode;
			head = newNode;
		}
		newNode.pre = null;
	}

	@Override
	public void display() {
		Node current = head;

		if (head == null)
			return;

		while (current != null) {
			System.out.println(current.data + " ");
			current = current.next;
		}

	}

	@Override
	public void addLast(T element) {
		Node newNode = new Node(element);
		Node current = head;
		if (head == null) {
			head = tail = newNode;
		} else {
			while (current.next != null) {
				current = current.next;
			}
			current.next = newNode;
			newNode.pre = current;
		}
	}

	@Override
	public void deleteFirst() {
		if (head == null)
			return;
		if (head.next == null) {
			head = null;
			tail = null;
		} else {
			head.next.pre = null;
			head = head.next;

		}

	}

	@Override
	public void deleteLast() {
		if (head == null)
			return;
		if (head.next == null) {
			head = null;
			tail = null;
		} else {
			Node current = head;
			Node temp = null;
			while (current.next != null) {
				temp = current;
				current = current.next;
			}

			temp.next = null;
			current.pre = null;

		}
	}

	@Override
	public void deleteFromGivenPosition(int position) {
		if (head == null)
			return;
		if (position == 1) {
			deleteFirst();
		} else {
			current = head;
			temp = null;
			for (int i = 1; current != null && i < position; i++) {
				temp = current;
				current = current.next;
			}
			if (current.next == null)
				deleteLast();
			else {
				temp.next = current.next;
				current.next.pre = temp;
				current.pre = null;
				current.next = null;
			}
		}

	}

	public boolean search(T element) {
		current = head;
		while (current != null) {
			if (element == current.data) {
				return true;
			}
			current = current.next;
		}
		return false;

	}
}
