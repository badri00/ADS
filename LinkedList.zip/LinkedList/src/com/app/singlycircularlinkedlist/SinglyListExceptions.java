package com.app.singlycircularlinkedlist;

public class SinglyListExceptions extends RuntimeException {

	public SinglyListExceptions(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
