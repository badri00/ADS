package com.app.singlycircularlinkedlist;

public class Tester {

	public static void main(String[] args) {
		
			SinglyListImpl<Integer> list = new SinglyListImpl<>();
			//list.addFirst(10);
			list.addNewElement(1, 1);
			list.addNewElement(2, 2);
			list.addNewElement(3, 3);
			list.addNewElement(4, 3);
			list.addNewElement(5, 3);
//			list.addNewElement(3, 4);
//			list.addNewElement(5, 5);
			list.displayList();
			//list.addNewElement(100, 100);
			System.out.println("--------------------------------------------");
//			SinglyListImpl<Integer> list1 = new SinglyListImpl<>();
//			list1.addNewElement(6, 1);
//			list1.addNewElement(7, 2);
//			list1.addNewElement(8, 3);
//			list1.addNewElement(9, 4);
//			list1.addNewElement(10, 5);
//			list1.addNewElement(11, 6);
//			list1.displayList();
			//list1.addNewElement(100, 100);
			System.out.println("--------------------------------------------");

				list.addFirst(11);
//		list.addLast(5);
	list.addLast(6);
//		list.addLast(7);
//		list.displayList();
		//list.deleteFirst();
//		list.deleteFirst();
//		list.deleteFirst();
		//list.deleteLast();
	//list.deleteLast();
//		list.deleteElement(1);
		list.displayList();
//		list.deleteAll();
//		list.displayList();
//		list.addNewElement(1, 1);
//		list.displayList();
		//list.reverseList();
	//list.displayList();
//		list.moveNodeToFirstPosition(4);
//		list.displayList();

//		list.insertInSortedList(8);
//		list.displayList();
			// list.removeDuplicateElements();
//			SinglyListImpl<Integer> list2 = list.mergeList(list, list1);
			//list2.displayList();
		
	}

}
