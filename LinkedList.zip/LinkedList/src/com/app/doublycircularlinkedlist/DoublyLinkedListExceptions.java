package com.app.doublycircularlinkedlist;

public class DoublyLinkedListExceptions extends RuntimeException {

	public DoublyLinkedListExceptions(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
