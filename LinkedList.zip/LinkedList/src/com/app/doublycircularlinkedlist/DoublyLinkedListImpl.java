package com.app.doublycircularlinkedlist;

import com.app.singlylinkedlist.SinglyListExceptions;

public class DoublyLinkedListImpl<T> implements DoublyLinkedList<T> {

	public class Node {

		T data;
		Node pre;
		Node next;

		public Node(T data) {
			super();
			this.data = data;
			this.pre = null;
			this.next = null;
		}

		public Node() {
			super();
			this.data = null;
			this.pre = null;
			this.next = null;
		}
	}

	Node head;
	Node tail;
	Node current;
	Node temp;

	public DoublyLinkedListImpl() {
		super();
		this.head = null;
		this.tail = null;
	}

	@Override
	public T addNewElement(T element, int position) {

		if (head == null || position <= 1)
			addFirst(element);
		else {
			Node newNode = new Node(element);
			current = head;
			for (int i = 1; i < position - 1; i++) {
				if (current.next == head)
					throw new DoublyLinkedListExceptions("Position is greater than number of nodes");
				current = current.next;
			}
			if (current.next == head)
				addLast(element);
			else {
				newNode.next = current.next;
				current.next = newNode;
				newNode.pre = current;
				current.next.pre = newNode;
			}
		}

		return element;
	}

	@Override
	public void addFirst(T element) {
		Node newNode = new Node(element);
		if (head == null) {
			head = newNode;
			head.next = head;
			head.pre = head;
		} else {
			newNode.next = head;
			newNode.pre = head.pre;
			head.pre.next = newNode;
			head.pre = newNode;
			head = newNode;
		}

	}

	@Override
	public void display() {

		if (head == null) {
			System.out.println("List is empty !!");
			return;
		}
		Node current = head;

		do {
			System.out.println(current.data + " ");
			current = current.next;
		} while (current != head);

	}

	@Override
	public void addLast(T element) {
		Node newNode = new Node(element);

		if (head == null) {
			head = newNode;
			newNode.next = head;
			newNode.pre = head;
		} else {
			newNode.next = head;
			newNode.pre = head.pre;
			head.pre.next = newNode;
			head.pre = newNode;

		}
	}

	@Override
	public void deleteFirst() {
		if (head == null) {
			System.out.println("List is empty");
			return;
		}

		if (head.next == null) {
			head = null;
			tail = null;
		} else {

			head.next.pre = head.pre;
			head.pre.next = head.next;
			head = head.next;

		}

	}

	@Override
	public void deleteLast() {
		if (head == null) {
			System.out.println("List is empty");
			return;
		}
		if (head.next == null) {
			head = null;
			tail = null;
		} else {

			head.pre.pre.next = head;
			head.pre = head.pre.pre;

		}
	}

	@Override
	public void deleteFromGivenPosition(int position) {
		if (head == null)
			return;
		if (position == 1) {
			deleteFirst();
		} else {
			current = head;
			temp = null;
			for (int i = 1; i < position; i++) {

				if (current.next == head)
					throw new DoublyLinkedListExceptions("Position is greater than number of nodes");
				temp = current;
				current = current.next;
			}
			if (current.next == head)
				deleteLast();
			else {
				temp.next = current.next;
				current.next.pre = temp;
				current.pre = null;
				current.next = null;
			}
		}

	}

	public boolean search(T element) {
		current = head;
		do {
			if (element == current.data) {
				return true;
			}
			current = current.next;
		}while (current != head);
		return false;

	}
}
