package com.app.doublycircularlinkedlist;

public class Tester {

	public static void main(String[] args) {
		//DoublyLinkedList<Integer> dl = new DoublyLinkedListImpl<>();
		DoublyLinkedList dl = new DoublyLinkedListImpl();
		
		dl.addNewElement(1, 1);
		dl.addNewElement(2, 2);
		dl.addNewElement(3, 3);
//		dl.addNewElement(4, 4);
//		dl.addNewElement(5, 5);
		dl.addNewElement("Vivek", 3);
		dl.addFirst(8);
//		dl.addFirst(9);
		dl.addLast(6);
		//dl.addNewElement(100, 100);

//		dl.deleteFirst();
//
//		dl.deleteLast();

		//dl.deleteFromGivenPosition(5);
//		 dl.deleteFromGivenPosition(1);
		dl.display();
		// dl.deleteFromGivenPosition(6);
		boolean key = dl.search("Vivek");
		if (key == true)
			System.out.println("element found");
		else
			System.out.println("element not found");

	}
}
